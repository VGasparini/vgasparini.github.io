# Changelog

## [1.0.0] 2018-07-25

### Original Release